<?php
/**
 * 公共方法
 * @name common
 * @package cws
 * @category include
 * @link
 * @author
 * @version 1.0
 * @copyright
 * @since 2018-12-18
 */
namespace common;
use think\Db;
use chrome\ChromePhp;
class Common {
	/**
	 * 生成GUID
	 */
	public static function guid() {		
		if (function_exists ( 'com_create_guid' )) {
			$guid= com_create_guid ();
		} else {
			mt_srand ( ( double ) microtime () * 10000 ); // optional for php 4.2.0 and up.
			$charid = strtoupper ( md5 ( uniqid ( rand (), true ) ) );
			$hyphen = chr ( 45 ); // "-"
			$uuid = chr ( 123 ) . 			// "{"
			substr ( $charid, 0, 8 ) . $hyphen . substr ( $charid, 8, 4 ) . $hyphen . substr ( $charid, 12, 4 ) . $hyphen . substr ( $charid, 16, 4 ) . $hyphen . substr ( $charid, 20, 12 ) . chr ( 125 ); // "}"
			$guid=$uuid;			
		}
		return substr($guid, 1,36);
	}
	
	/**
	 * 获取当前时间
	 * @return string time 2016-08-02 16:01:01
	 */
	public static function getTime(){
	    return date('Y-m-d H:i:s',time());
	}
	
	/**
	 * 生成返回信息数组
	 * @param int $errorCode
	 * @param string $errorInfo
	 * @param array $data
	 */
	static function errorArray($errorCode, $errorInfo, $data){
		$result ["errorCode"] = $errorCode;
		$result ["errorInfo"] = $errorInfo;//提示信息
		$result ["data"] = $data;
		return $result;
	}

	/**
	 * 控制器权限验证
	 * @param array $session
	 * @param string $go
	 */
	public static function rightVerify($session,$go){
		if (!isset($session))
		{
			echo "<html><head><meta http-equiv='refresh' content='0;url=".$go."'></head><body></body><ml>";
			echo "<script type='text/javascript'>window.location.href('".$go."');</script>";
			exit;
		}
	}
	
	/**
	 * 索引编码
	 * @param string $str
	 * @return string
	 */
	public static function encodeIndex($str){
		$data = explode(" ",$str);
		$data = array_filter($data);
		$data = array_flip(array_flip($data));
		foreach ($data as $ss) {
			if(strlen($ss) > 1){
				$data_code .= str_replace("%", "", urlencode($ss));
			}
		}
		return trim($data_code);
		//SELECT * FROM fulltext_sample WHERE MATCH(copy) AGAINST('E696B9E581A5E4BDA0E5A5BD');
	}
	
	/**
	 * 获取ip地址
	 * @return stirng	
	 */
	public static function getRealIp(){
		$ip=false;
		if(!empty($_SERVER["HTTP_CLIENT_IP"])){
			$ip = $_SERVER["HTTP_CLIENT_IP"];
		}
		if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ips = explode (", ", $_SERVER['HTTP_X_FORWARDED_FOR']);
			if ($ip) { array_unshift($ips, $ip); $ip = FALSE; }
			for ($i = 0; $i < count($ips); $i++) {
				if (!eregi ("^(10|172\.16|192\.168)\.", $ips[$i])) {
					$ip = $ips[$i];
					break;
				}
			}
		}
		return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
	}
	
	/**
	 * 获取ip所属信息
	 * @param string $ip
	 * @return mixed
	 */
	public static function getAreaByIp($ip){
		$taobaoUrl = "http://ip.taobao.com/service/getIpInfo.php?ip={$ip}";
		/*
		 * {"code":0,"data":{"country":"中国","country_id":"CN","area":"华东","area_id":"300000","region":"安徽省","region_id":"340000","city":"合肥市","city_id":"340100","county":"","county_id":"-1","isp":"电信","isp_id":"100017","ip":"114.97.7.229"}}
		 */
		$rawResult = file_get_contents($taobaoUrl);
		$result = json_decode($rawResult);
		$result = (array)$result;
		$result = (array)$result['data'];
		return $result;
	}
	
	
	
	/**
	 * 识别设备
	 * @return string
	 */
	public static function detectDevice(){
		$user_agent = $_SERVER['HTTP_USER_AGENT'];
		if(stristr($user_agent,'iPad')) {
			return 'iPad';
		}else if(stristr($user_agent,'Android')) {
			return 'Android';
		}else if(stristr($user_agent,'Linux')){
			return 'Linux';
		}else if(stristr($user_agent,'iPhone')){
			return 'iPhone';
		}else if(stristr($user_agent,'iPad')){
			return 'iPad';
		}else if(stristr($user_agent,'Windows Phone')){
			return 'WP';
		}else{
			return 'other';
		}
	}
	
	/**
	 *  @desc 根据两点间的经纬度计算距离
	 *  @param float $lat1  第一个点纬度值
	 *  @param float $lng1  第一个点经度值
	 *  @param float $lat2  第二个点纬度值
	 *  @param float $lng2  第二个点经度值
	 *  @return int 距离 单位米
	 */
	static function getDistance($lat1, $lng1, $lat2, $lng2){
		$earthRadius = 6367000; //地球圆周率
	    //第一个点
		$lat1 = ($lat1 * pi() ) / 180;
		$lng1 = ($lng1 * pi() ) / 180;
    	//第二个点
		$lat2 = ($lat2 * pi() ) / 180;
		$lng2 = ($lng2 * pi() ) / 180;
	    //计算距离
		$calcLongitude = $lng2 - $lng1;
		$calcLatitude = $lat2 - $lat1;
		$stepOne = pow(sin($calcLatitude / 2), 2) + cos($lat1) * cos($lat2) * pow(sin($calcLongitude / 2), 2);
		$stepTwo = 2 * asin(min(1, sqrt($stepOne)));
		$calculatedDistance = $earthRadius * $stepTwo;
		return round($calculatedDistance);
	}
	//-----------------------------------------计算时间差函数--------------------------------------------
	/**
	 * 两个日期之间相差的天数
	 * (针对1970年1月1日之后，求之前可以采用泰勒公式)
	 * @param string $begin_time
	 * @param string $end_time
	 * @param int $type 默认0返回时间戳 ,1返回 array , 2返回天数 ,3返回小时,4返回分钟
	 * @return array [day:1,hour:2,min:36,sec:40] or string $timediff
	 */
	static function timediff($begin_time, $end_time,$type = 0){
	    $begin_time = strtotime($begin_time);
	    $end_time = strtotime($end_time);
	    $starttime = $begin_time;
	    $endtime = $end_time;
	    $timediff = intval($endtime) - intval($starttime);
	    if($type == 0){
	        return $timediff;
	    }elseif($type == 1){
	        $days = intval( $timediff / 86400 );
	        $remain = $timediff % 86400;
	        $hours = intval( $remain / 3600 );
	        $remain = $remain % 3600;
	        $mins = intval( $remain / 60 );
	        $secs = $remain % 60;
	        $res = array( "day" => $days, "hour" => $hours, "min" => $mins, "sec" => $secs );
	        return $res;
	    }elseif($type == 2){
	        $time = round($timediff / 86400,2);
	        if($time >= 0){
	            return ceil($timediff / 86400);
	        }else{
	            return -1;
	        }
	    }elseif($type == 3){
	        $hours = intval( $timediff / 3600 );
	        return $hours;
	    }elseif($type == 4){
	        $mins = round( $timediff / 60 , 3);
	        return $mins;
	    }
	}

	/**
	 * 分页查询数据
	 * @param string $table 表名
	 * @param array $page
	 * @param array  $conditionList
	 *  array(
	 *  	array("field" => "name","operator" => "=","value" => input('phone'),
	 *  	array("field" => "name","operator" => "like","value" => input('name'),
	 *  	array("field" => "id","operator" => "in","value" => input('ids'),
	 *  	array("field" => "name","operator" => ">=","value" => input('from'),
	 *  	array("field" => "name","operator" => "<=","value" => input('to')
	 *  )
	 * @param string $sort
	 * @param array $orList
	        $orList = array();
			$orConditionList = array();
			array_push($orConditionList, array('field'=>"option_name","operator"=>"like","value"=>"{input('searchText')}"));
			array_push($orConditionList, array('field'=>"num","operator"=>"=","value"=>"{input('searchText')}"));
			array_push($orList, $orConditionList);
	 * @return array
	 */
	static function paging($table,$page,$conditionList,$sort = '',$orList = null)
	{
		$page['pageIndex'] ? $pageIndex = $page['pageIndex'] : $pageIndex = 1;
		$page['pageSize'] ? $pageSize = $page['pageSize'] : $pageSize = 10;
		//与连接条件
		$orString = '';
		if(null != $orList && '' != $orList && count($orList) > 0){
			foreach ($orList as $orConditionList){
				if(empty($orConditionList)){//如果为空跳出循环
					$orString = "";
					break;
				}
				$per = "(";

//				foreach ($orConditionList as $orCondition){
					if('like' == $orConditionList['operator']){
						$per .= " {$orConditionList['field']} like  '%{$orConditionList['value']}%' AND";
					}else if('in' == $orConditionList['operator']){
						$per .= " {$orConditionList['field']} in  ({$orConditionList['value']}) AND";
					}else{
						$per .= " {$orConditionList['field']} {$orConditionList['operator']}" . self::isNumberic($orConditionList['value']) . " AND";
					}
//				}
				$per = rtrim($per,"AND") . ")";
				$orString .= "{$per} AND";
			}
			$orString = '('.rtrim($orString,"AND").')';
		}
		//和连接条件
		$whereString = "";
		if(count($conditionList) > 0){
			foreach ($conditionList as $condition){
				if('like' == $condition['operator']){
					$whereString .= " {$condition['field']} like '%{$condition['value']}%' AND";
				}else if('in' == $condition['operator']){
					$whereString .= " {$condition['field']} in ({$condition['value']}) AND";
				}else{
					
					$whereString .= " {$condition['field']} {$condition['operator']}" . self::isNumberic($condition['value']) . " AND";
				}
			}
			$whereString = rtrim($whereString,"AND");
			$sql = "SELECT * FROM {$table} WHERE{$whereString} ";
			if($orString){
				$sql = "{$sql}OR {$orString} ";
			}
		}else{
			if($orString){
				$sql = "SELECT * FROM {$table} WHERE {$orString}";
			}else{
				$sql = "SELECT * FROM {$table} ";
			}
		}

		//排序
		if(null != $sort && '' != $sort){
			$sort = "ORDER BY {$sort}";
		}
		//分页
		$m = ($pageIndex -1) * $pageSize;
		$n =  $pageSize;
		$sqlLimit =  "{$sql}{$sort} LIMIT {$m}, {$n}";

		try {
			$result['dataList'] = Db::query($sqlLimit);
			$sql = "SELECT count(*) as total_record_num  from ( {$sql} ) as count_table";
			$count = Db::query($sql);
			//如果之后1页，手动添加分页信息
//			if($result['pageInfo']==NULL){
				$result['pageInfo']['current_page'] = $pageIndex;
				$result['pageInfo']['first_page'] = 1;
				$result['pageInfo']['prev_page']=$pageIndex - 1;
				$result['pageInfo']['next_page']=$pageIndex + 1;
				$result['pageInfo']['last_page']=ceil ($count[0]['total_record_num'] / $pageSize);
				$result['pageInfo']['total_count']= $count[0]['total_record_num'];
				$result['pageInfo']['total_page'] = ceil ($count[0]['total_record_num'] / $pageSize)==0?1:ceil ($count[0]['total_record_num'] / $pageSize);
				$result['pageInfo']['page_size'] = $pageSize;
				$result['pageInfo']['all_pages'] = ceil ($count[0]['total_record_num'] / $pageSize);
//			}
			return common::errorArray(0, "查询成功", $result);
		} catch (Exception $ex) {return common::errorArray(1, "数据库操作失败", $ex);}
	}
	
	/**
	 * 分页查询数据（表连接方式）
	 * @param array $table 
	 * array(
	 *	 	'left'=>"cg_left", 
	 * 	"right"=>"cg_right", 
	 * 	"left_on"=>"id",
	 * 	"right_on"=>"lid",
	 *		 "fieldList"=>array(
	 * 			"name",
	 * 			"phone",
	 * 			"add_time",
	 * 		)
	 * )
	 * @param array $page
	 * @param array  $conditionList fields operator value
	 * @param string $sort
	 * @return array
	 */
	static function pagingJoin($table,$page,$conditionList,$sort = '')
	{
		$page['pageIndex'] ? $pageIndex = $page['pageIndex'] : $pageIndex = 1;
		$page['pageSize'] ? $pageSize = $page['pageSize'] : $pageSize = 10;
		$rightFields = "";
		foreach ($table['fieldList'] as $fieldAlias=>$field){
			if( is_numeric($fieldAlias) ){
				$rightFields .= "right_table.{$field},";
			}else{
				$rightFields .= "right_table.{$field} as $fieldAlias,";
			}
		}
		$rightFields = rtrim($rightFields,",");
		//条件
		$leftWhereString = "";
		$rightWhereString = "";
		if(count($conditionList) > 0){
			foreach ($conditionList as $condition){
				$firList = explode('_', $condition['field']);
				if($firList[0] == 'lf'){
					unset($firList[0]);
					$condition['field'] = implode('_',$firList);
					if('like' == $condition['operator']){
						$leftWhereString .= " {$condition['field']} like '%{$condition['value']}%' AND";
					}else if('in' == $condition['operator']){
						$leftWhereString .= " {$condition['field']} in ({$condition['value']}) AND";
					}else{
						$leftWhereString .= " {$condition['field']} {$condition['operator']}" . self::isNumberic($condition['value']) . " AND";
					}
				}elseif($firList[0] == 'rg'){
					unset($firList[0]);
					$condition['field'] = implode('_',$firList);
					if('like' == $condition['operator']){
						$rightWhereString .= " a.{$condition['field']} like '%{$condition['value']}%' AND";
					}else if('in' == $condition['operator']){
						$rightWhereString .= " a.{$condition['field']} in ({$condition['value']}) AND";
					}else{
						$leftWhereString .= "  a.{$condition['field']} {$condition['operator']}" . self::isNumberic($condition['value']) . " AND";
					}
				}
			}
			$leftWhereString = rtrim($leftWhereString,"AND");
			$rightWhereString = rtrim($rightWhereString,"AND");
			if($leftWhereString == '' && $rightWhereString != ''){
				$sql = "SELECT * FROM (SELECT left_table.*,{$rightFields} FROM  {$table['left']} as left_table left join  {$table['right']}  as right_table on left_table.{$table['left_on']} = right_table.{$table['right_on']}) AS a where{$rightWhereString} ";
			}else if($leftWhereString != '' && $rightWhereString == ''){
				$sql = "SELECT left_table.*,{$rightFields} FROM (SELECT * FROM {$table['left']} WHERE {$leftWhereString}) as left_table left join  {$table['right']}  as right_table on left_table.{$table['left_on']} = right_table.{$table['right_on']} ";
			}else if($leftWhereString != '' && $rightWhereString != ''){
				$sql = "SELECT * FROM (SELECT left_table.*,{$rightFields} FROM (SELECT * FROM {$table['left']} WHERE {$leftWhereString}) as left_table left join  {$table['right']}  as right_table on left_table.{$table['left_on']} = right_table.{$table['right_on']}) AS a where{$rightWhereString} ";
			}
		}else{
			$sql = "SELECT left_table.*,{$rightFields} FROM {$table['left']} as left_table left join  {$table['right']}  as right_table on left_table.{$table['left_on']} = right_table.{$table['right_on']} ";
		}
		
		//排序
		if(null != $sort && '' != $sort){
			$sort = "ORDER BY {$sort}";
		}
		//分页
		$m = ($pageIndex -1) * $pageSize;
		$n =  $pageSize;
		$sqlLimit =  "{$sql}{$sort} LIMIT {$m}, {$n}";
		try {
			$result ['dataList'] = Db::query($sqlLimit);
			$sql = "SELECT count(count_table.id) as total_record_num  from ( {$sql} ) as count_table";
			
			$count = Db::query($sql);
			//如果之后1页，手动添加分页信息
			$result['pageInfo']['current_page'] = $pageIndex;
			$result['pageInfo']['first_page'] = 1;
			$result['pageInfo']['prev_page']=$pageIndex - 1;
			$result['pageInfo']['next_page']=$pageIndex + 1;
			$result['pageInfo']['last_page']=ceil ($count[0]['total_record_num'] / $pageSize);
			$result['pageInfo']['total_count']= $count[0]['total_record_num'];
			$result['pageInfo']['total_page'] = ceil ($count[0]['total_record_num'] / $pageSize)==0?1:ceil ($count[0]['total_record_num'] / $pageSize);
			$result['pageInfo']['page_size'] = $pageSize;
			$result['pageInfo']['all_pages'] = ceil ($count[0]['total_record_num'] / $pageSize);
			return common::errorArray(0, "查询成功", $result);
		} catch (Exception $ex) {return common::errorArray(1, "数据库操作失败", $ex);}
	}
	
	
	/*
	 * 判断字符串是否为数字
	 */
	static function isNumberic($val){
		if(is_numeric($val)){
			$string = $val;
		}else{
			$string = "'" . $val . "'";
		}
		return $string;
	}
	
	

}