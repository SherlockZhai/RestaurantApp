<?php
/**
 * 微信网页授权
 * @name UserAuth
 * @package cws
 * @category include
 * @link
 * @author
 * @version 2.0
 * @copyright
 * @since 2016-08-09
 */
namespace wechatUtil;
class UserAuth {
	/**
	 * 校验session后
	 * 获取用户收货地址的code后重定向到goBack
	 */
	public static function verify($goBack,$scope='snsapi_base',$goBreak){
		if(session('user') == null || session('user') == '' || 
			session("user.authInfo.openid") == null || session("user.authInfo.access_token") == null){
		    
		    if($goBreak !=""){//用户自定义的回调地址
		        $goBack = $goBreak;
		    }
			$goBack= urlencode($goBack);

			WeChatOAuth::getCode("public/index.php/common/FrontController/main?goBack={$goBack}",1,$scope);
		}else{
			//判断授权是否过期
			$result = WeChatOAuth::checkAccessToken(session("user.authInfo.access_token"), session("user.authInfo.openid"));
			if($result['errcode'] != 0){//过期的时候自动刷新
				$authInfo = WeChatOAuth::refreshToken(session("user.authInfo.refresh_token"));
				session("user.authInfo",$authInfo);
			}
		}
	}
	
	/**
	 * 校验session后
	 * 获取用户收货地址的code后重定向到goBack
	 */
	public static function verifyPay($goBack){
		if(!session("user.payAuth")){
			$goBack= urlencode($goBack);
			WeChatOAuth::getCode("index.php/common/FrontController/payAuth?goBack={$goBack}",1);
		}else{
			//判断授权是否过期
			$result = WeChatOAuth::checkAccessToken(session("user.payAuth.access_token"), session("user.payAuth.openid"));
			if($result['errcode'] != 0){//过期的时候自动刷新
				$payAuth = WeChatOAuth::refreshToken(session("user.payAuth.refresh_token"));
				session("user.payAuth",$payAuth);
			}
		}
	}
}
