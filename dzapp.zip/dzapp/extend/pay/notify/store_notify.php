<?php
/**
 *支付成功后通知
 * @name store_notify.php
 * @package cwms
 * @category controller
 * @link /controller/notify.php
 * @author
 * @version 1.0
 * @since 2015-7-25
 */
/*
 appid:wx63a6e52d04f9ed63
bank_type:CMB_CREDIT 付款银行
cash_fee:1
fee_type:CNY 
is_subscribe :Y 是否关注公众账号
mch_id:1247415201
nonce_str:bv4kv9du5y12olx9w3nff0yjvqfgpic0
openid:ob2eYuNyzq-AgR-vi3llKvIW2h1o
out_trade_no:hhffi8666
result_code:SUCCESS
return_code:SUCCESS
sign:14F44FEF0835B4257FBAC7D807AD06AE
time_end:20150726152935
total_fee:1
trade_type:JSAPI
transaction_id:1007880445201507260482512729
 */

$postStr = file_get_contents('php://input');
$postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
if( $postObj->return_code == "SUCCESS"){
		if($postObj->result_code == "SUCCESS"){ 			
			require __DIR__ . '/../../../application/database.php';
            require_once __DIR__."/../notify/lib/WxPay.BankCard.php";

			$dbms='mysql';     //数据库类型
			$host=$database['hostname']; //数据库主机名
			$dbName=$database['database'];    //使用的数据库
			$user=$database['username'];      //数据库连接用户名
			$pass=$database['password'];          //对应的密码
			$dsn="$dbms:host=$host;dbname=$dbName";
			$dbh = new PDO($dsn, $user, $pass); //初始化一个PDO对象
	
			$rawOrderNum = $postObj->out_trade_no;
			$orderNumList = explode('_', $rawOrderNum);
			if($orderNumList[1]){//该订单修改过,去处传入的修改次数
			  $orderNum = $orderNumList[0];
			}else{
			  $orderNum = $postObj->out_trade_no;
			}
			$sql = "SELECT * FROM base_order WHERE order_num =  '{$orderNum}'";
			
			$orderInfo = $dbh->query($sql)->fetch(2);
			

			if($orderInfo['transaction_id']){//订单已处理直接结束
				echo 'success';
				exit;
			}
			//更新订单信息
			 $sql = "UPDATE `base_order` SET `state`=:state,`transaction_id`=:transaction_id,`end_time`=:end_time,`pay_card`=:pay_card WHERE `id`=:id";
			 $dbh->prepare($sql)->execute(['state'=>1,'transaction_id'=>$postObj->transaction_id,'end_time'=>date("Y-m-d H:i:s",time()),'pay_card'=>BankCard::GetBankCard($postObj->bank_type),'id'=>$orderInfo['id']]);

		}
}
echo 'success';