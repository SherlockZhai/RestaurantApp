<?php
require __DIR__ . '/../../../public/wechatConfig.php';//引入微信配置为文件//导入微信配置
require __DIR__ . '/../../../application/database.php';

require_once __DIR__."/../notify/lib/WxPay.Api.php";
require_once __DIR__."/../notify/lib/WxPay.JsApiPay.php";
require_once __DIR__."/../notify/lib/WxPay.Config.php";

$dbms='mysql';     //数据库类型
$host=$database['hostname']; //数据库主机名
$dbName=$database['database'];    //使用的数据库
$user=$database['username'];      //数据库连接用户名
$pass=$database['password'];          //对应的密码
$dsn="$dbms:host=$host;dbname=$dbName";
$dbh = new PDO($dsn, $user, $pass); //初始化一个PDO对象
$sql ="set names utf8";
$dbh->query($sql);
$sql = "SELECT * FROM base_order WHERE id = {$_GET['oid']}";
$orderInfo = $dbh->query($sql)->fetch(2);

//微信支付标题
$wechatPayTitleSql = "SELECT * FROM platform_config WHERE item_key = 'wechat_pay_title'";
$wechatPayTitle = $dbh->query($wechatPayTitleSql)->fetch(2);

//微信支付接口

$orderArgsObj = new WxPayUnifiedOrder();

//设置必填参数
if($orderInfo['price_times']){
    $orderInfo['order_num'] = $orderInfo['order_num'] . "_" . $orderInfo['price_times'];
}
$orderArgsObj->SetOut_trade_no( $orderInfo['order_num']);
$orderArgsObj->SetBody($wechatPayTitle['item_value']);
$orderArgsObj->SetTotal_fee($orderInfo['total_price'] * 100);//单位是分
$orderArgsObj->SetTrade_type('JSAPI');
$orderArgsObj->SetOpenid($orderInfo['account']);
$orderArgsObj->SetTime_start(date("YmdHis"));
$orderArgsObj->SetTime_expire(date("YmdHis", time() + 30000));
//是否开启微信小程序
//$orderArgsObj->SetWXapp_state(IS_WXAPP);
$wxappState = IS_WXAPP;
//异步通知url未设置，则使用配置文件中的url
$orderArgsObj->SetNotify_url(WxPayConfig::STORE_NOTIFY_URL);//异步通知url

$payResult = WxPayApi::unifiedOrder($orderArgsObj,'',$wxappState);

$pay = new JsApiPay();
try{
	$jsApiParameters = $pay->GetJsApiParameters($payResult);
}catch (Exception $ex){//发生异常重定向
// 	header("location: {$configInfo['wechat_url']}/index.php?c=store&a=index");
}
echo $jsApiParameters;
