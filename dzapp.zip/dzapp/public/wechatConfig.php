<?php
require __DIR__ . '/../application/database.php';

$dbms='mysql';     //数据库类型
$host=$database['hostname']; //数据库主机名
$dbName=$database['database'];    //使用的数据库
$user=$database['username'];      //数据库连接用户名
$pass=$database['password'];          //对应的密码
$dsn="$dbms:host=$host;dbname=$dbName";
$dbh = new PDO($dsn, $user, $pass); //初始化一个PDO对象
$sql = "SELECT * FROM weixin_config WHERE item_group = 'wechat'";
$rawConfigInfo = $dbh->query($sql)->fetchAll(2);

foreach($rawConfigInfo as  $perConfig){
	$configInfo[$perConfig['item_key']] = $perConfig['item_value'];
}

//微信配置
define('DEBUG', $configInfo['is_debug']);////1、调试模式 0、生产环境
define('WECHAT_TYPE', $configInfo['wechat_type']);//0服务号1订阅号 2企业号

define("WECHAT_URL", $configInfo['wechat_url']);//授权后重定向的回调链接地址，请使用urlencode对链接进行处理 后面加反斜杠/
define('WECHAT_ENCODING_AES_KEY', $configInfo['wechat_encoding_aes_key']);
define('WECHAT_TOKEN', $configInfo['wechat_token']);
define("WECHAT_NUMBER", $configInfo['wechat_number'] );//微信号

define('IS_WXAPP', $configInfo['is_wxapp']);//0 不开启小程序 1 开启小程序
$is_wxapp = $configInfo['is_wxapp'];//0 不开启小程序 1 开启小程序
define("WXAPP_APPID", $configInfo['wxapp_appid']);
define("WXAPP_APPSECRET", $configInfo['wxapp_appsecret'] );
define("WXAPP_MCHID", $configInfo['wxapp_mchid']);//商户号（必须配置，开户邮件中可查看）
define("WXAPP_PAY_KEY", $configInfo['wxapp_pay_key']);//商户支付密钥，参考开户邮件设置（必须配置，登录商户平台自行设置）
define("WECHAT_APPID", $configInfo['wechat_appid']);
define("WECHAT_APPSECRET", $configInfo['wechat_appsecret'] );
define("WECHAT_MCHID", $configInfo['wechat_mchid']);//商户号（必须配置，开户邮件中可查看）
define("WECHAT_PAY_KEY", $configInfo['wechat_pay_key']);//商户支付密钥，参考开户邮件设置（必须配置，登录商户平台自行设置）
define("WECHAT_STORE_NOTIFY_URL", $configInfo['wechat_store_notify_url']);//微商城支付通知url


