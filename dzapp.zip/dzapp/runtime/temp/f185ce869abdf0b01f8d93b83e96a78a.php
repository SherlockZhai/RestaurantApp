<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:79:"/www/wwwroot/dzapp/public/../application/admin/view/2024/Login/login/login.html";i:1715312107;s:70:"/www/wwwroot/dzapp/application/admin/view/2024/common/page/dialog.html";i:1715312106;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login | Restaurant Booking App Backend Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="robots" content="index,follow">
    <meta name="application-name" content="">
    <!-- local CSS -->
    <link href="/public/static/js/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/application/admin/view/<?php echo $theme; ?>/Login/login/login.css">
	<link rel="stylesheet" href="/public/static/iconfont/admin/iconfont.css">
    <!-- Favicons -->
    <link rel="icon" href="/public/static/images/admin/favicon.ico" sizes="16x16 32x32">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="/public/static/js/respond.min.js" type="text/javascript"></script>
    <script src="/public/static/js/html5shiv.min.js" type="text/javascript"></script>
    <![endif]-->
</head>
<body>
<div id="header">
    <div class="logo fl">
        <a href="" target="_blank" style="display: none;">
            <img src="/application/admin/view/<?php echo $theme; ?>/Login/login/image/logo2.png">
        </a>
    </div>
    <div class="line fl"></div>
    <div class="welcome-login fl">
        <div>Hello! Welcome to the restaurant reservation backend management system</div>
    </div>
</div>
<div id="container">
    <!--登录区域-->
    <div class="login-area">
        <h3>Welcome</h3>
         <ul>
         	<div class="notice" style="visibility: hidden;">
         		<img src="/application/admin/view/<?php echo $theme; ?>/Login/login/image/logo.png">
         	</div>
             <li class="error-info"></li>
             <li class="clearfix">
                 <div class="account-info login-info">
                 	
                     <span class="fl title-info" title="Account"><i class="icon iconfont">&#xe64b;</i></span>
                     <input type="text" class="fl" tabindex="1" id="account" placeholder="Please enter your account" value="<?php if(\think\Cookie::get('account')): ?><?php echo \think\Cookie::get('account'); endif; ?>">
                 </div>
             </li>
             <li class="clearfix">
                 <div class="password-info login-info">
                     <span class="fl title-info" title="Password"><i class="icon iconfont">&#xe64a;</i></span>
                     <input type="password" class="fl" tabindex="2" id="password" placeholder="Please enter password"  value="<?php if(\think\Cookie::get('password')): ?><?php echo \think\Cookie::get('password'); endif; ?>">
                 </div>
             </li>
             <li class="clearfix btn-area">
                 <a class="btn-login" tabindex="3" id="btnLogin" href="javascript:;">Login</a>
             </li>
         </ul>
    </div>
</div>
<div id="footer">
    <div class="copyright">
        <a href="" target="_blank"></a>
    </div>
</div>
<!-- 模态框（Modal） 提示框-->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title">
                    prompt box
                </h4>
            </div>
            <div class="modal-body">
                Congratulations, the operation was successful!
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default close-action" data-dismiss="modal">Close</button>

            </div>
        </div><!-- /.modal-content -->
    </div>
</div><!-- /.modal -->

<!-- 模态框（Modal） 操作确认提示框-->
<div class="modal fade" id="deleteConfirmModal" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title">
                    Confirmation prompt box
                </h4>
            </div>
            <div class="modal-body">
                <p class="text-danger">Are you sure to delete it？</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-confirm">Confirm</button>
                <button type="button" class="btn btn-default close-action" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div>
</div><!-- /.modal -->

<!-- 模态框（Modal） 操作确认提示框-->
<div class="modal fade" id="myConfirmModal" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title">
                    Confirmation prompt box
                </h4>
            </div>
            <div class="modal-body">
                <p class="text-danger">Are you sure to delete it？</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-confirm">Confirm</button>
                <button type="button" class="btn btn-default close-action" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div>
</div><!-- /.modal -->
<!-- 模态框（Modal）操作持续中转圈提示 -->
<div class="modal fade" id="loading" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel">
    <div style="z-index: 9999;height: 100%;margin: 0 auto;text-align: center;line-height: 600px;">
        <img height="60px" src="/public/static/images/admin/loading.gif">
    </div>
</div><!-- /.modal -->

<script src="/public/static/js/jquery/jquery-1.11.0.js" type="text/javascript"></script>
<script src="/public/static/js/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="/application/admin/view/<?php echo $theme; ?>/common/js/login.js" type="text/javascript"></script>

</body>
</html>