<?php if (!defined('THINK_PATH')) exit(); /*a:7:{s:84:"/www/wwwroot/dzapp/public/../application/admin/view/2024/User/userList/userList.html";i:1715312107;s:68:"/www/wwwroot/dzapp/application/admin/view/2024/common/page/head.html";i:1715312107;s:70:"/www/wwwroot/dzapp/application/admin/view/2024/common/page/header.html";i:1715312107;s:68:"/www/wwwroot/dzapp/application/admin/view/2024/common/page/menu.html";i:1715312107;s:70:"/www/wwwroot/dzapp/application/admin/view/2024/common/page/footer.html";i:1715312107;s:70:"/www/wwwroot/dzapp/application/admin/view/2024/common/page/dialog.html";i:1715312106;s:71:"/www/wwwroot/dzapp/application/admin/view/2024/common/page/jsfiles.html";i:1715312107;}*/ ?>
<!DOCTYPE html>
<html>
<!-- head -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Restaurant reservation | backend management system</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="robots" content="index,follow">
    <meta name="application-name" content="">

    <!-- Favicons -->
    <link rel="icon" href="/public/static/images/admin/favicon.ico" sizes="16x16 32x32">
    <!-- local CSS -->
    <link href="/public/static/js/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/public/static/iconfont/admin/iconfont.css">
    <link href="/public/static/js/iCheck/skins/minimal/blue.css" rel="stylesheet">
    <link href="/public/static/js/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/application/admin/view/<?php echo $theme; ?>/common/css/default.css">
    <link rel="stylesheet" href="/application/admin/view/<?php echo $theme; ?>/common/css/skins/<?php echo $skin; ?>.css">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="/public/static/respond.min.js" type="text/javascript"></script>
    <script src="/public/static/html5shiv.min.js" type="text/javascript"></script>
    <link rel="stylesheet" href="/public/static/admin/view/common/css/ie.css">
    <![endif]-->

    <!--[if lt IE 8]>
    <script src="/public/static/js/json2.js"></script>
    <![endif]-->
</head>
<link rel="stylesheet" href="../../../application/admin/view/<?php echo $theme; ?>/User/userList/userList.css">
<body>
<!---------------- 用户列表 ------------------->

<!-- 页头 -->
<!-- 页头 -->
<div class="header container-fluid<?php if($leftBarScale == '1'): ?> scale<?php endif; ?>">
    <div class="row">
        <div class="col-md-2 col-sm-2 col-xs-12 logo">
            <a href="javascript:;" style="visibility: hidden"><img src="/public/static/../bg/logo.png"></a>
        </div>
        <div class="col-md-10 col-sm-10 col-xs-12 top">
            <div class="pull-left">
                
            </div>
            <div class="pull-right">
                <div class="quick-action">
                    <a href="javascript:;" class="changeSkin" skin="" style="display: none;">换肤
                        <ul>
                            <li><span title="黑色" class="black skin" skin="black"></span></li>
                            <li><span title="红色" class="red skin" skin="red"></span></li>
                            <li><span title="蓝色" class="blue skin" skin="blue"></span></li>
                            <li><span title="绿色" class="green skin" skin="green"></span></li>
                            <li><span title="紫色" class="purple skin" skin="purple"></span></li>
                            <li style="display: none;"><span title="卡奇" class="kaqi skin" skin="kaqi"></span></li>
                            <li><span title="黄色" class="yellow skin" skin="yellow"></span></li>
                            <li><span title="橘黄" class="orange skin" skin="orange"></span></li>
                            <li><span title="粉色" class="pink skin" skin="pink"></span></li>
                            <li><span title="天蓝" class="skyBlue skin" skin="skyBlue"></span></li>
                        </ul>
                    </a>
                </div>
                <div class="user-action">
                   
                    <a class="user"><?php echo \think\Session::get('admin.account'); ?></a>
                    <a href="../Login/logout" class="logo-out"><i class="icon iconfont">&#xe60c;</i>&nbsp;Exit</a></div>
                </div>
        </div>
    </div>
</div>

<!-- 主体 -->
<div class="content container-fluid<?php if($leftBarScale == '1'): ?> scale<?php endif; ?>">
    <div class="row">
        <div class="col-md-2 left-section">
            <!-- 左导航菜单 -->
            
<!--左边栏缩放-->
<div class="section-scale"><a class="btn-scale" href="javascript:;"><i class="icon iconfont">&#xe669;</i></a></div>
<!--左边栏菜单-->
<div class="nav-block menu">
	<!--一级导航-->
	<div class="nav-1-block">
	<?php if(is_array($topMenuList) || $topMenuList instanceof \think\Collection || $topMenuList instanceof \think\Paginator): if( count($topMenuList)==0 ) : echo "" ;else: foreach($topMenuList as $key=>$topMenu): ?>
		<a href="<?php if($topMenu['subList']): if(is_array($topMenu['subList']) || $topMenu['subList'] instanceof \think\Collection || $topMenu['subList'] instanceof \think\Paginator): if( count($topMenu['subList'])==0 ) : echo "" ;else: foreach($topMenu['subList'] as $j=>$subMenu): if($j == 0): if($subMenu['menuList']): if(is_array($subMenu['menuList']) || $subMenu['menuList'] instanceof \think\Collection || $subMenu['menuList'] instanceof \think\Paginator): if( count($subMenu['menuList'])==0 ) : echo "" ;else: foreach($subMenu['menuList'] as $k=>$menu): if($k == 0): ?><?php echo $menu['url'];break;; endif; endforeach; endif; else: echo "" ;endif; else: ?><?php echo $subMenu['url'];break;; endif; endif; endforeach; endif; else: echo "" ;endif; else: endif; ?>" <?php if($leftBarScale == '1'): ?>title="<?php echo $topMenu['name']; ?>"<?php endif; ?> class="a-nav-1 <?php if(\think\Session::get('currentMenu.menu_top_id') == $topMenu['id']): ?>active<?php endif; ?>">
			<i class="icon iconfont"><?php echo $topMenu['icon']; ?></i>
			<span class="top-menu-name"><?php echo $topMenu['name']; ?></span></span>
		</a>
		
		
		
	<?php endforeach; endif; else: echo "" ;endif; ?>
	</div>
	<!--2级导航-->
	<div class="nav-2-block">
		<?php foreach($menuList as $menu): ?>
			<a href="<?php if($menu['menuList']): ?>javascript:;<?php else: ?><?php echo $menu['url']; endif; ?>" class="a-nav-2<?php if(\think\Session::get('currentMenu.menu_id') == $menu['id']): ?> active<?php if($menu['menuList']): ?> a-nav-2-show<?php endif; elseif(\think\Session::get('currentMenu.mid') == $menu['id']): ?> active<?php endif; ?>"><?php if(!$menu['menuList']): ?><i class="icon iconfont"><?php echo $menu['icon']; ?></i><?php else: ?><span class="icon-arrow <?php if(\think\Session::get('currentMenu.menu_id') == $menu['id']): ?>icon-arrow-down<?php else: ?>icon-arrow-right<?php endif; ?>"></span><?php endif; ?><span class="menu-name"><?php echo $menu['name']; ?></span></span></a>
			<!--存在第三级菜单-->
			<?php if($menu['menuList']): ?>
			<div class="nav-3-block<?php if(\think\Session::get('currentMenu.menu_id') == $menu['id']): ?> show<?php endif; ?>">
    		<?php if(is_array($menu['menuList']) || $menu['menuList'] instanceof \think\Collection || $menu['menuList'] instanceof \think\Paginator): if( count($menu['menuList'])==0 ) : echo "" ;else: foreach($menu['menuList'] as $key=>$subMenu): ?>
		       <a href="<?php echo $subMenu['url']; ?>" class="a-nav-3 <?php if(\think\Session::get('currentMenu.mid') == $subMenu['id']): ?>active<?php endif; ?>"><i class="icon iconfont"><?php echo $subMenu['icon']; ?></i><span class="menu-name"><?php echo $subMenu['name']; ?></span></span></a>
    		<?php endforeach; endif; else: echo "" ;endif; ?>
    		</div>
    		<?php endif; endforeach; ?>
	</div>
</div>
<input type="hidden" id="menuId" value="<?php echo \think\Session::get('currentMenu.mid'); ?>">
<input type="hidden" id="roleTypes" value="<?php echo $roleTypes; ?>">
<input type="hidden" id="meun_id" value="<?php echo $menu_id; ?>">

        </div>
        <div class="col-md-10 right-section">
            <!--内容区域-->
            <h3><i class="icon iconfont"><?php echo \think\Session::get('currentMenu.icon'); ?></i><?php echo \think\Session::get('currentMenu.menuTitle'); ?>
            	
            </h3>
            <div class="inner-section row">
                <!--查询区域-->
                <div class="search-param-panel">
                    <form class="search-param-form" id="search-param-form">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">

                            <tr>
                                <td width="60px">
                                    <label for="account">Account:&nbsp;</label>
                                </td>
                                <td width="140px">
                                    <input id="account" name="account" type="text" class="input-normal search" />
                                </td>
                                <td width="60px">
                                    <label for="phone">Phone:&nbsp;</label>
                                </td>
                                <td width="140px">
                                    <input id="phone" name="phone" type="text" class="input-normal search" />
                                </td>


                                <td>
                                    <div class="list-action-area">
                                        <a href="javascript:;" class="search-button btn btn-primary btn-sm">Search</a>
                                    </div>
                                </td>

                            </tr>
                        </table>
                    </form>
                </div>

                <div class="list-title">
                    <div class="list-title-panel">
                        <span class="glyphicon glyphicon-list"></span>List</span>
                    </div>
                </div>
                <div class="item table-responsive">
                    <table id="list-table" class="list-table table table-striped table-hover table-bordered table-base">
                        <tbody>
                        </tbody>
                    </table>
                </div>
                <!--分页-->
                <div id="page-selection"></div>
            </div>
        </div>
    </div>
</div>

<!-- 页脚 -->
<!-- 页脚 -->
<div class="hidden footer<?php if($leftBarScale == '1'): ?> scale<?php endif; ?>">
    <div>COPYRIGHT © 2015 <a target="_blank" href=""></a> DESIGN. ALL RIGHTS RESERVED.</div>
</div>
<!-- 返回上部图标 -->
<div class="up-nav bottom-fixed hidden">
	<div class="up-icon bottom-icon">
		<i class="icon iconfont">&#xe621;</i>
	</div>
</div>
<!-- 模态框（Modal） 提示框-->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title">
                    prompt box
                </h4>
            </div>
            <div class="modal-body">
                Congratulations, the operation was successful!
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default close-action" data-dismiss="modal">Close</button>

            </div>
        </div><!-- /.modal-content -->
    </div>
</div><!-- /.modal -->

<!-- 模态框（Modal） 操作确认提示框-->
<div class="modal fade" id="deleteConfirmModal" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title">
                    Confirmation prompt box
                </h4>
            </div>
            <div class="modal-body">
                <p class="text-danger">Are you sure to delete it？</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-confirm">Confirm</button>
                <button type="button" class="btn btn-default close-action" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div>
</div><!-- /.modal -->

<!-- 模态框（Modal） 操作确认提示框-->
<div class="modal fade" id="myConfirmModal" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title">
                    Confirmation prompt box
                </h4>
            </div>
            <div class="modal-body">
                <p class="text-danger">Are you sure to delete it？</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-confirm">Confirm</button>
                <button type="button" class="btn btn-default close-action" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div>
</div><!-- /.modal -->
<!-- 模态框（Modal）操作持续中转圈提示 -->
<div class="modal fade" id="loading" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel">
    <div style="z-index: 9999;height: 100%;margin: 0 auto;text-align: center;line-height: 600px;">
        <img height="60px" src="/public/static/images/admin/loading.gif">
    </div>
</div><!-- /.modal -->


<!-- jsfiles -->
<!-- javascript plugins-->
<script type="text/javascript" src="/public/static/js/jquery/jquery-1.11.0.js"></script>
<script type="text/javascript" src="/public/static/js/bootstrap/js/bootstrap.js"></script>
<!--bootstrap分页插件-->
<script type="text/javascript" src="/public/static/js/jquery.bootpag/jquery.bootpag.min.js"></script>
<!--复选框、单选按钮效果增强插件-->
<script type="text/javascript" src="/public/static/js/iCheck/icheck.min.js"></script>
<script type="text/javascript" src="/public/static/js/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!--日历插件-->
<script src="/public/static/js/My97DatePicker/WdatePicker.js"></script>
<!--表单验证插件-->
<script type="text/javascript" src="/public/static/js/form/jquery.form.js"></script>
<script type="text/javascript" src="/public/static/js/form/jquery.validate.js"></script>
<script type="text/javascript" src="/public/static/js/form/jquery.validate.extend.js"></script>
<!--省市区县-->
<script type="text/javascript" src="/public/static/js/address.js"></script>
<script type="text/javascript" src="/application/admin/view/<?php echo $theme; ?>/common/js/global.js"></script>
<script type="text/javascript" src="../../../application/admin/view/<?php echo $theme; ?>/User/userList/userList.js"></script>
</body>
</html>